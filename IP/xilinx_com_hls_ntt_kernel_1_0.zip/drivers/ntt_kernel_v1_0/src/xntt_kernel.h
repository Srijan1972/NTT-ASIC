// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XNTT_KERNEL_H
#define XNTT_KERNEL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xntt_kernel_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XNtt_kernel_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XNtt_kernel;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNtt_kernel_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNtt_kernel_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNtt_kernel_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNtt_kernel_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XNtt_kernel_Initialize(XNtt_kernel *InstancePtr, UINTPTR BaseAddress);
XNtt_kernel_Config* XNtt_kernel_LookupConfig(UINTPTR BaseAddress);
#else
int XNtt_kernel_Initialize(XNtt_kernel *InstancePtr, u16 DeviceId);
XNtt_kernel_Config* XNtt_kernel_LookupConfig(u16 DeviceId);
#endif
int XNtt_kernel_CfgInitialize(XNtt_kernel *InstancePtr, XNtt_kernel_Config *ConfigPtr);
#else
int XNtt_kernel_Initialize(XNtt_kernel *InstancePtr, const char* InstanceName);
int XNtt_kernel_Release(XNtt_kernel *InstancePtr);
#endif

void XNtt_kernel_Start(XNtt_kernel *InstancePtr);
u32 XNtt_kernel_IsDone(XNtt_kernel *InstancePtr);
u32 XNtt_kernel_IsIdle(XNtt_kernel *InstancePtr);
u32 XNtt_kernel_IsReady(XNtt_kernel *InstancePtr);
void XNtt_kernel_EnableAutoRestart(XNtt_kernel *InstancePtr);
void XNtt_kernel_DisableAutoRestart(XNtt_kernel *InstancePtr);

void XNtt_kernel_Set_x(XNtt_kernel *InstancePtr, u64 Data);
u64 XNtt_kernel_Get_x(XNtt_kernel *InstancePtr);
void XNtt_kernel_Set_psi_powers(XNtt_kernel *InstancePtr, u64 Data);
u64 XNtt_kernel_Get_psi_powers(XNtt_kernel *InstancePtr);
void XNtt_kernel_Set_twiddles(XNtt_kernel *InstancePtr, u64 Data);
u64 XNtt_kernel_Get_twiddles(XNtt_kernel *InstancePtr);
void XNtt_kernel_Set_q(XNtt_kernel *InstancePtr, u32 Data);
u32 XNtt_kernel_Get_q(XNtt_kernel *InstancePtr);
void XNtt_kernel_Set_q_inv(XNtt_kernel *InstancePtr, u32 Data);
u32 XNtt_kernel_Get_q_inv(XNtt_kernel *InstancePtr);
void XNtt_kernel_Set_batch_size(XNtt_kernel *InstancePtr, u32 Data);
u32 XNtt_kernel_Get_batch_size(XNtt_kernel *InstancePtr);
void XNtt_kernel_Set_n(XNtt_kernel *InstancePtr, u32 Data);
u32 XNtt_kernel_Get_n(XNtt_kernel *InstancePtr);

void XNtt_kernel_InterruptGlobalEnable(XNtt_kernel *InstancePtr);
void XNtt_kernel_InterruptGlobalDisable(XNtt_kernel *InstancePtr);
void XNtt_kernel_InterruptEnable(XNtt_kernel *InstancePtr, u32 Mask);
void XNtt_kernel_InterruptDisable(XNtt_kernel *InstancePtr, u32 Mask);
void XNtt_kernel_InterruptClear(XNtt_kernel *InstancePtr, u32 Mask);
u32 XNtt_kernel_InterruptGetEnabled(XNtt_kernel *InstancePtr);
u32 XNtt_kernel_InterruptGetStatus(XNtt_kernel *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
